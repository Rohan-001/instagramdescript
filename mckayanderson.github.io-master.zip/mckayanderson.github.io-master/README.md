# mckayanderson.github.io
Terminal based portfolio website for mckay
